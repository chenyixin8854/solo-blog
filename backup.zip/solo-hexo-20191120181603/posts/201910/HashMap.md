title: HashMap
date: '2019-10-15 23:58:30'
updated: '2019-10-15 23:58:30'
tags: [JDK]
permalink: /articles/2019/10/15/1571155110012.html
---
初始化容量、最大容量、扩容因子、节点table、entrySet、数据量
```
    static final int DEFAULT_INITIAL_CAPACITY = 1 << 4; // aka 16

    static final int MAXIMUM_CAPACITY = 1 << 30;

    static final float DEFAULT_LOAD_FACTOR = 0.75f;

    transient Node<K,V>[] table;

    transient Set<Map.Entry<K,V>> entrySet;

    transient int size;
```

计算Hash值
```
    static final int hash(Object key) {
        int h;
        return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
    }

```
