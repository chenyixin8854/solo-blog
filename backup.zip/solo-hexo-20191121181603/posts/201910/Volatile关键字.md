title: Volatile关键字
date: '2019-10-16 15:32:45'
updated: '2019-10-16 15:32:45'
tags: [待分类]
permalink: /articles/2019/10/16/1571211165229.html
---
![](https://img.hacpai.com/bing/20180617.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**volatile特性之一：**

保证变量在线程之间的可见性。可见性的保证是基于CPU的内存屏障指令，被JSR-133抽象为happens-before原则。

  

**volatile特性之二：**

  

阻止编译时和运行时的指令重排。编译时JVM编译器遵循内存屏障的约束，运行时依靠CPU屏障指令来阻止重排。
