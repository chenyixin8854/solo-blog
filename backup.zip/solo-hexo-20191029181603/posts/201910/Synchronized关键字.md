title: Synchronized关键字
date: '2019-10-18 13:37:56'
updated: '2019-10-18 13:40:53'
tags: [JDK]
permalink: /articles/2019/10/18/1571377076340.html
---
![](https://img.hacpai.com/bing/20171210.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

synchronized关键字的原理
由偏向锁->轻量级锁->自适应自旋锁->重量级锁膨胀
![null](https://upload-images.jianshu.io/upload_images/4491294-e3bcefb2bacea224.png?imageMogr2/auto-orient/strip|imageView2/2/format/webp)
